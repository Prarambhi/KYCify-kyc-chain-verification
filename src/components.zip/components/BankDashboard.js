import React, { useState, useEffect } from 'react';
import { useWallet } from '../contexts/WalletContext';
import { 
  Box, Typography, Card, CardContent, Button,
  CircularProgress, List, ListItem, ListItemText, ListItemAvatar,
  Divider, Dialog, DialogTitle, DialogContent,
  DialogActions, Alert, Tabs, Tab,
  Chip, Avatar, TextField, Grid, Paper, Badge
} from '@mui/material';
import { ethers } from 'ethers';
import KYCContractABI from '../contracts/KYCContract.json';
import BusinessIcon from '@mui/icons-material/Business';
import PersonIcon from '@mui/icons-material/Person';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import DescriptionIcon from '@mui/icons-material/Description';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';

const darkBlueTheme = {
  primary: '#0a192f',
  secondary: '#172a45',
  accent: '#64ffda',
  textPrimary: '#e6f1ff',
  textSecondary: '#8892b0',
  paperBackground: '#112240'
};

const CONTRACT_ADDRESS = "0xB9C07F9b7f06b4190337DE33148FcCe83Bf3a667";

function BankDashboard() {
  const { account } = useWallet();
  const [bankDetails, setBankDetails] = useState(null);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [approvedCustomers, setApprovedCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [contract, setContract] = useState(null);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [error, setError] = useState('');
  const [tabValue, setTabValue] = useState(0);
  const [remarks, setRemarks] = useState('');
  const [newRequestsCount, setNewRequestsCount] = useState(0);

  // Helper function to safely convert BigInt to Number
  const convertBigInt = (value) => {
    if (typeof value === 'bigint') {
      return Number(value.toString());
    }
    return value;
  };

  const getInitial = (name) => {
    if (!name || typeof name !== 'string' || name.length === 0) return 'B';
    return name.charAt(0).toUpperCase();
  };

  const formatWalletAddress = (address) => {
    if (!address || typeof address !== 'string' || address.length < 10) return address;
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return 'N/A';
    const timestampNumber = convertBigInt(timestamp);
    return new Date(timestampNumber * 1000).toLocaleString();
  };

  useEffect(() => {
    const initContract = async () => {
      if (window.ethereum && account) {
        try {
          const provider = new ethers.BrowserProvider(window.ethereum);
          const signer = await provider.getSigner();
          
          const kycContract = new ethers.Contract(
            CONTRACT_ADDRESS,
            KYCContractABI.abi,
            signer
          );
          
          setContract(kycContract);
          
          // Set up event listeners
          kycContract.on("BankRequestedAccess", (customerId, bankId) => {
            if (bankDetails && bankId.toString() === bankDetails.id.toString()) {
              setNewRequestsCount(prev => prev + 1);
              fetchCustomerRequests(kycContract);
            }
          });
          
          await fetchBankDetails(kycContract);
          await fetchCustomerRequests(kycContract);
        } catch (error) {
          console.error("Error initializing contract:", error);
          setError("Failed to connect to contract: " + error.message);
          setLoading(false);
        }
      }
    };

    initContract();

    return () => {
      if (contract) {
        contract.removeAllListeners("BankRequestedAccess");
      }
    };
  }, [account]);

  const fetchBankDetails = async (contract) => {
    try {
      setLoading(true);
      const bankId = await contract.bankIds(account);
      if (convertBigInt(bankId) === 0) {
        throw new Error("Bank not registered");
      }
      
      const details = await contract.banks(bankId);
      setBankDetails({
        id: convertBigInt(bankId),
        name: details.name || 'Not available',
        bankNumber: details.bankNumber || 'Not available',
        country: details.country || 'Not available',
        state: details.state || 'Not available',
        pincode: details.pincode || 'Not available',
        adminName: details.adminName || 'Not available',
        walletAddress: details.walletAddress || account,
        isApproved: details.isApproved || false,
        passwordHash: details.passwordHash || 'Not available'
      });
    } catch (error) {
      console.error("Error fetching bank details:", error);
      setError("Failed to load bank details: " + error.message);
    }
  };

  const fetchCustomerRequests = async (contract) => {
    try {
      setLoading(true);
      setError('');
      
      const bankId = await contract.bankIds(account);
      if (convertBigInt(bankId) === 0) {
        throw new Error("Bank not registered");
      }
      
      const pendingCustomerIds = await contract.getBankPendingRequests(bankId);
      const requests = [];
      
      for (let i = 0; i < pendingCustomerIds.length; i++) {
        const customerId = pendingCustomerIds[i];
        const customer = await contract.customers(customerId);
        const documents = await contract.getCustomerDocuments(customerId);
        
        requests.push({
          customerId: convertBigInt(customerId),
          customerAddress: customer.walletAddress,
          username: customer.username,
          documentName: customer.documentName,
          documents: documents,
          requestDate: convertBigInt(customer.approvalDate) || 0,
          status: convertBigInt(customer.status),
          remarks: customer.remarks
        });
      }
      
      setPendingRequests(requests);
      
      const approvedCustomerIds = await contract.getBankApprovedCustomers(bankId);
      const approved = [];
      
      for (let i = 0; i < approvedCustomerIds.length; i++) {
        const customerId = approvedCustomerIds[i];
        const customer = await contract.customers(customerId);
        const documents = await contract.getCustomerDocuments(customerId);
        
        approved.push({
          id: convertBigInt(customerId),
          username: customer.username,
          documentName: customer.documentName,
          walletAddress: customer.walletAddress,
          status: convertBigInt(customer.status),
          approvalDate: convertBigInt(customer.approvalDate),
          remarks: customer.remarks,
          documents: documents
        });
      }
      
      setApprovedCustomers(approved);
      setNewRequestsCount(0);
    } catch (error) {
      console.error("Error fetching customer requests:", error);
      setError("Failed to load customer requests: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleApproveRequest = async () => {
    try {
      setLoading(true);
      setError('');
      
      if (!contract || !selectedRequest) {
        throw new Error("Contract or request not initialized");
      }

      const tx = await contract.approveCustomer(
        selectedRequest.customerId,
        remarks || "Approved by bank"
      );
      
      await tx.wait();
      setOpenDialog(false);
      setRemarks('');
      await fetchCustomerRequests(contract);
    } catch (error) {
      console.error("Approval error:", error);
      setError(error.message || "Failed to approve customer");
    } finally {
      setLoading(false);
    }
  };

  const handleRejectRequest = async () => {
    try {
      setLoading(true);
      setError('');
      
      if (!contract || !selectedRequest) {
        throw new Error("Contract or request not initialized");
      }

      const tx = await contract.rejectCustomer(
        selectedRequest.customerId,
        remarks || "Rejected by bank"
      );
      
      await tx.wait();
      setOpenDialog(false);
      setRemarks('');
      await fetchCustomerRequests(contract);
    } catch (error) {
      console.error("Rejection error:", error);
      setError(error.message || "Failed to reject customer");
    } finally {
      setLoading(false);
    }
  };

  const refreshData = async () => {
    if (contract) {
      setLoading(true);
      try {
        await fetchBankDetails(contract);
        await fetchCustomerRequests(contract);
      } catch (error) {
        console.error("Error refreshing data:", error);
        setError("Failed to refresh data");
      }
    }
  };

  return (
    <Box sx={{ 
      p: 3,
      background: darkBlueTheme.primary,
      minHeight: '100vh',
      color: darkBlueTheme.textPrimary
    }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Avatar sx={{ 
          bgcolor: darkBlueTheme.accent,
          width: 56, 
          height: 56 
        }}>
          <BusinessIcon sx={{ color: darkBlueTheme.primary }} />
        </Avatar>
        <Typography variant="h4" sx={{ 
          fontWeight: 700,
          letterSpacing: 1
        }}>
          Bank Dashboard
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ 
          mb: 3,
          backgroundColor: 'rgba(255, 0, 0, 0.1)',
          color: '#ff6e6e',
          border: '1px solid rgba(255, 0, 0, 0.2)'
        }}>
          {error}
        </Alert>
      )}
      
      {/* Bank Information Section */}
      <Card sx={{ 
        mb: 4,
        backgroundColor: darkBlueTheme.paperBackground,
        border: `1px solid ${darkBlueTheme.secondary}`,
        borderRadius: 3
      }}>
        <CardContent>
          <Box sx={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center', 
            mb: 2 
          }}>
            <Typography variant="h5" sx={{ color: darkBlueTheme.textPrimary }}>
              Bank Information
            </Typography>
            <Button 
              variant="outlined" 
              onClick={refreshData}
              disabled={loading}
              startIcon={loading ? <CircularProgress size={20} /> : <RefreshIcon />}
              sx={{
                color: darkBlueTheme.accent,
                borderColor: darkBlueTheme.accent,
                '&:hover': {
                  backgroundColor: 'rgba(100, 255, 218, 0.1)',
                  borderColor: darkBlueTheme.accent
                }
              }}
            >
              Refresh
            </Button>
          </Box>
          
          {loading && !bankDetails ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress sx={{ color: darkBlueTheme.accent }} />
            </Box>
          ) : bankDetails ? (
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Paper elevation={0} sx={{ 
                  p: 2, 
                  backgroundColor: darkBlueTheme.secondary,
                  borderRadius: 2,
                  height: '100%'
                }}>
                  <Typography variant="subtitle1" sx={{ 
                    mb: 1,
                    color: darkBlueTheme.textPrimary
                  }}>
                    Bank Details
                  </Typography>
                  <Divider sx={{ 
                    mb: 2,
                    backgroundColor: darkBlueTheme.textSecondary
                  }} />
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                    <Avatar sx={{ 
                      mr: 2, 
                      width: 56, 
                      height: 56, 
                      bgcolor: bankDetails.isApproved ? darkBlueTheme.accent : 'warning.main',
                      fontSize: '1.5rem',
                      color: bankDetails.isApproved ? darkBlueTheme.primary : 'inherit'
                    }}>
                      {getInitial(bankDetails.name)}
                    </Avatar>
                    <Box>
                      <Typography variant="h6" sx={{ color: darkBlueTheme.textPrimary }}>
                        {bankDetails.name}
                      </Typography>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        Bank ID: {bankDetails.id}
                      </Typography>
                    </Box>
                  </Box>
                  
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        <strong>Bank Number:</strong>
                      </Typography>
                      <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                        {bankDetails.bankNumber}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        <strong>Admin Name:</strong>
                      </Typography>
                      <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                        {bankDetails.adminName}
                      </Typography>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Paper elevation={0} sx={{ 
                  p: 2, 
                  backgroundColor: darkBlueTheme.secondary,
                  borderRadius: 2,
                  height: '100%'
                }}>
                  <Typography variant="subtitle1" sx={{ 
                    mb: 1,
                    color: darkBlueTheme.textPrimary
                  }}>
                    Location & Status
                  </Typography>
                  <Divider sx={{ 
                    mb: 2,
                    backgroundColor: darkBlueTheme.textSecondary
                  }} />
                  
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        <strong>Country:</strong>
                      </Typography>
                      <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                        {bankDetails.country}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        <strong>State:</strong>
                      </Typography>
                      <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                        {bankDetails.state}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        <strong>Pincode:</strong>
                      </Typography>
                      <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                        {bankDetails.pincode}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                        <strong>Status:</strong>
                      </Typography>
                      <Chip 
                        label={bankDetails.isApproved ? 'Approved' : 'Pending Approval'} 
                        sx={{ 
                          mt: 0.5,
                          backgroundColor: bankDetails.isApproved ? 'rgba(100, 255, 218, 0.2)' : 'rgba(255, 193, 7, 0.2)',
                          color: bankDetails.isApproved ? darkBlueTheme.accent : 'warning.light'
                        }}
                        size="small"
                      />
                    </Grid>
                  </Grid>
                  
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                      <strong>Wallet Address:</strong>
                    </Typography>
                    <Typography variant="body2" sx={{ 
                      fontFamily: 'monospace',
                      wordBreak: 'break-all',
                      color: darkBlueTheme.textPrimary
                    }}>
                      {bankDetails.walletAddress}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          ) : (
            <Typography variant="body1" sx={{ 
              textAlign: 'center', 
              py: 4,
              color: darkBlueTheme.textSecondary
            }}>
              No bank details found. Please complete your bank registration.
            </Typography>
          )}
        </CardContent>
      </Card>

      {/* Customer Management Section */}
      <Card sx={{ 
        backgroundColor: darkBlueTheme.paperBackground,
        border: `1px solid ${darkBlueTheme.secondary}`,
        borderRadius: 3
      }}>
        <CardContent>
          <Tabs 
            value={tabValue} 
            onChange={(e, newValue) => setTabValue(newValue)} 
            sx={{ 
              mb: 3,
              '& .MuiTabs-indicator': {
                backgroundColor: darkBlueTheme.accent
              }
            }}
            variant="fullWidth"
          >
            <Tab 
              label={
                <Badge 
                  badgeContent={newRequestsCount} 
                  color="error" 
                  invisible={newRequestsCount === 0}
                >
                  <Box sx={{ color: darkBlueTheme.textPrimary }}>
                    Pending Requests ({pendingRequests.length})
                  </Box>
                </Badge>
              } 
              sx={{ color: darkBlueTheme.textSecondary }}
            />
            <Tab 
              label={
                <Box sx={{ color: darkBlueTheme.textPrimary }}>
                  Approved Customers ({approvedCustomers.length})
                </Box>
              }
              sx={{ color: darkBlueTheme.textSecondary }}
            />
          </Tabs>
          
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress sx={{ color: darkBlueTheme.accent }} />
            </Box>
          ) : tabValue === 0 ? (
            pendingRequests.length > 0 ? (
              <List>
                {pendingRequests.map((request) => (
                  <React.Fragment key={request.customerId}>
                    <ListItem sx={{ py: 2 }}>
                      <ListItemAvatar>
                        <Avatar sx={{ 
                          bgcolor: darkBlueTheme.secondary,
                          color: darkBlueTheme.accent
                        }}>
                          {getInitial(request.username)}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                            {request.username}
                          </Typography>
                        }
                        secondary={
                          <Box sx={{ mt: 0.5 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <DescriptionIcon sx={{ 
                                fontSize: 16, 
                                color: darkBlueTheme.textSecondary,
                                mr: 0.5
                              }} />
                              <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                                Document: {request.documentName}
                              </Typography>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <AccountBalanceWalletIcon sx={{ 
                                fontSize: 16, 
                                color: darkBlueTheme.textSecondary,
                                mr: 0.5
                              }} />
                              <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                                Wallet: {formatWalletAddress(request.customerAddress)}
                              </Typography>
                            </Box>
                            <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                              Request Date: {formatDate(request.requestDate)}
                            </Typography>
                          </Box>
                        }
                      />
                      <Button 
                        variant="outlined" 
                        onClick={() => {
                          setSelectedRequest(request);
                          setOpenDialog(true);
                        }}
                        sx={{
                          color: darkBlueTheme.accent,
                          borderColor: darkBlueTheme.accent,
                          '&:hover': {
                            backgroundColor: 'rgba(100, 255, 218, 0.1)',
                            borderColor: darkBlueTheme.accent
                          }
                        }}
                      >
                        Review
                      </Button>
                    </ListItem>
                    <Divider sx={{ backgroundColor: darkBlueTheme.secondary }} />
                  </React.Fragment>
                ))}
              </List>
            ) : (
              <Typography variant="body1" sx={{ 
                textAlign: 'center', 
                py: 4,
                color: darkBlueTheme.textSecondary
              }}>
                No pending customer requests
              </Typography>
            )
          ) : approvedCustomers.length > 0 ? (
            <List>
              {approvedCustomers.map((customer) => (
                <ListItem key={customer.id} sx={{ py: 2 }}>
                  <ListItemAvatar>
                    <Avatar sx={{ 
                      bgcolor: darkBlueTheme.secondary,
                      color: darkBlueTheme.accent
                    }}>
                      {getInitial(customer.username)}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                        {customer.username}
                      </Typography>
                    }
                    secondary={
                      <Box sx={{ mt: 0.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <DescriptionIcon sx={{ 
                            fontSize: 16, 
                            color: darkBlueTheme.textSecondary,
                            mr: 0.5
                          }} />
                          <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                            Document: {customer.documentName}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <AccountBalanceWalletIcon sx={{ 
                            fontSize: 16, 
                            color: darkBlueTheme.textSecondary,
                            mr: 0.5
                          }} />
                          <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                            Wallet: {formatWalletAddress(customer.walletAddress)}
                          </Typography>
                        </Box>
                        <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                          Approved on: {formatDate(customer.approvalDate)}
                        </Typography>
                        {customer.remarks && (
                          <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                            Remarks: {customer.remarks}
                          </Typography>
                        )}
                      </Box>
                    }
                  />
                  <Chip 
                    label="Approved" 
                    sx={{ 
                      backgroundColor: 'rgba(100, 255, 218, 0.2)',
                      color: darkBlueTheme.accent
                    }} 
                  />
                </ListItem>
              ))}
            </List>
          ) : (
            <Typography variant="body1" sx={{ 
              textAlign: 'center', 
              py: 4,
              color: darkBlueTheme.textSecondary
            }}>
              No approved customers
            </Typography>
          )}
        </CardContent>
      </Card>

      {/* Request Review Dialog */}
      <Dialog 
        open={openDialog} 
        onClose={() => {
          setOpenDialog(false);
          setRemarks('');
          setError('');
        }}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            backgroundColor: darkBlueTheme.paperBackground,
            color: darkBlueTheme.textPrimary,
            borderRadius: 3,
            border: `1px solid ${darkBlueTheme.secondary}`
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: darkBlueTheme.secondary,
          borderBottom: `1px solid ${darkBlueTheme.secondary}`
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <DescriptionIcon sx={{ color: darkBlueTheme.accent }} />
            <Typography>Review KYC Request</Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          {selectedRequest && (
            <>
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" sx={{ color: darkBlueTheme.textPrimary }}>
                  {selectedRequest.username}
                </Typography>
                <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                  Customer ID: {selectedRequest.customerId} | Request Date: {formatDate(selectedRequest.requestDate)}
                </Typography>
              </Box>
              
              <Grid container spacing={2} sx={{ mb: 2 }}>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                    <strong>Document Name:</strong>
                  </Typography>
                  <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                    {selectedRequest.documentName}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                    <strong>Wallet Address:</strong>
                  </Typography>
                  <Typography variant="body2" sx={{ 
                    fontFamily: 'monospace',
                    color: darkBlueTheme.textPrimary
                  }}>
                    {selectedRequest.customerAddress}
                  </Typography>
                </Grid>
              </Grid>
              
              <Typography variant="subtitle1" sx={{ 
                mt: 2, 
                mb: 1,
                color: darkBlueTheme.textPrimary
              }}>
                Submitted Documents:
              </Typography>
              <List dense>
                {selectedRequest.documents.map((doc, index) => (
                  <ListItem key={index} sx={{ py: 1 }}>
                    <ListItemText
                      primary={
                        <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                          Document {index + 1}
                        </Typography>
                      }
                      secondary={
                        <Box sx={{ mt: 0.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="body2" sx={{ 
                              color: darkBlueTheme.textSecondary,
                              mr: 1
                            }}>
                              Type:
                            </Typography>
                            <Typography variant="body2" sx={{ color: darkBlueTheme.textPrimary }}>
                              {doc.docType}
                            </Typography>
                          </Box>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="body2" sx={{ 
                              color: darkBlueTheme.textSecondary,
                              mr: 1
                            }}>
                              Hash:
                            </Typography>
                            <Typography variant="body2" sx={{ 
                              color: darkBlueTheme.textPrimary,
                              fontFamily: 'monospace',
                              wordBreak: 'break-all'
                            }}>
                              {doc.docHash}
                            </Typography>
                          </Box>
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
              </List>
              
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Remarks"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                sx={{ mt: 2 }}
                placeholder="Enter your approval/rejection remarks..."
                InputProps={{
                  style: {
                    color: darkBlueTheme.textPrimary
                  }
                }}
                InputLabelProps={{
                  style: {
                    color: darkBlueTheme.textSecondary
                  }
                }}
              />
            </>
          )}
        </DialogContent>
        <DialogActions sx={{ 
          p: 3,
          borderTop: `1px solid ${darkBlueTheme.secondary}`
        }}>
          <Button 
            onClick={() => {
              setOpenDialog(false);
              setRemarks('');
              setError('');
            }}
            sx={{ 
              color: darkBlueTheme.textSecondary,
              '&:hover': {
                color: darkBlueTheme.accent
              }
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleRejectRequest}
            variant="contained"
            startIcon={<CancelIcon />}
            sx={{
              backgroundColor: 'rgba(255, 0, 0, 0.2)',
              color: '#ff6e6e',
              '&:hover': {
                backgroundColor: 'rgba(255, 0, 0, 0.3)'
              },
              px: 3,
              py: 1,
              borderRadius: 2
            }}
            disabled={loading}
          >
            Reject
          </Button>
          <Button 
            onClick={handleApproveRequest}
            variant="contained"
            startIcon={<CheckCircleIcon />}
            sx={{
              backgroundColor: 'rgba(100, 255, 218, 0.2)',
              color: darkBlueTheme.accent,
              '&:hover': {
                backgroundColor: 'rgba(100, 255, 218, 0.3)'
              },
              px: 3,
              py: 1,
              borderRadius: 2
            }}
            disabled={loading}
          >
            Approve
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default BankDashboard;
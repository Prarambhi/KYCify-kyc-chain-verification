import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import axios from 'axios';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Stepper,
  Step,
  StepLabel,
  Divider,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Chip,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Link,
  TextField,
  Paper,
  Badge
} from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import SendIcon from '@mui/icons-material/Send';
import VerifiedIcon from '@mui/icons-material/Verified';
import DescriptionIcon from '@mui/icons-material/Description';
import InfoIcon from '@mui/icons-material/Info';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import PersonIcon from '@mui/icons-material/Person';
import BusinessIcon from '@mui/icons-material/Business';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import KYCContractABI from '../contracts/KYCContract.json';

const darkBlueTheme = {
  primary: '#0a192f',
  secondary: '#172a45',
  accent: '#64ffda',
  textPrimary: '#e6f1ff',
  textSecondary: '#8892b0',
  paperBackground: '#112240'
};

const CONTRACT_ADDRESS = "0xB9C07F9b7f06b4190337DE33148FcCe83Bf3a667";

const convertBigInt = (value) => {
  if (typeof value === 'bigint') {
    return Number(value.toString());
  }
  return value;
};

const CustomerDashboard = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedBank, setSelectedBank] = useState('');
  const [documents, setDocuments] = useState([]);
  const [verificationStatus, setVerificationStatus] = useState(0);
  const [verificationHash, setVerificationHash] = useState('');
  const [bankRequests, setBankRequests] = useState([]);
  const [availableBanks, setAvailableBanks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [infoOpen, setInfoOpen] = useState(false);
  const [ipfsHashes, setIpfsHashes] = useState({});
  const [customerDetails, setCustomerDetails] = useState(null);
  const [customerDocuments, setCustomerDocuments] = useState([]);

  const steps = ['Upload Documents', 'Select Bank', 'Verification'];

  const requiredDocuments = [
    { name: "Government-issued ID", types: ["Passport", "Driver's License", "National ID"] },
    { name: "Proof of Address", types: ["Utility Bill", "Bank Statement", "Lease Agreement"] },
    { name: "Tax Identification Number", types: ["TIN Certificate", "Tax Return"] }
  ];

  const statusMap = {
    0: 'Pending',
    1: 'Approved',
    2: 'Rejected',
    3: 'Verified'
  };

  const getStatusChip = (status) => {
    const statusText = statusMap[status] || 'Unknown';
    let color = 'default';
    
    switch (status) {
      case 0: color = 'warning'; break;
      case 1: color = 'success'; break;
      case 2: color = 'error'; break;
      case 3: color = 'info'; break;
      default: color = 'default';
    }
    
    return <Chip 
      label={statusText} 
      sx={{ 
        backgroundColor: color === 'success' ? 'rgba(100, 255, 218, 0.2)' : 
              color === 'error' ? 'rgba(255, 0, 0, 0.2)' : 
              color === 'warning' ? 'rgba(255, 193, 7, 0.2)' : 
              'rgba(66, 165, 245, 0.2)',
        color: color === 'success' ? darkBlueTheme.accent : 
               color === 'error' ? '#ff6e6e' : 
               color === 'warning' ? 'warning.light' : 'info.light'
      }} 
    />;
  };

  // ... (keep all your existing functions like getCustomerId, fetchCustomerData, etc.) ...

  return (
    <Box sx={{ 
      p: 4,
      background: darkBlueTheme.primary,
      minHeight: '100vh',
      color: darkBlueTheme.textPrimary
    }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Avatar sx={{ 
          bgcolor: darkBlueTheme.accent,
          width: 56, 
          height: 56 
        }}>
          <PersonIcon sx={{ color: darkBlueTheme.primary }} />
        </Avatar>
        <Typography variant="h4" sx={{ 
          fontWeight: 700,
          letterSpacing: 1
        }}>
          KYC Verification Dashboard
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ 
          mb: 3,
          backgroundColor: 'rgba(255, 0, 0, 0.1)',
          color: '#ff6e6e',
          border: '1px solid rgba(255, 0, 0, 0.2)'
        }}>
          {error}
        </Alert>
      )}
      {success && (
        <Alert severity="success" sx={{ 
          mb: 3,
          backgroundColor: 'rgba(100, 255, 218, 0.2)',
          color: darkBlueTheme.accent,
          border: `1px solid ${darkBlueTheme.accent}`
        }}>
          {success}
        </Alert>
      )}

      {/* Customer Status Overview Card */}
      <Card sx={{ 
        mb: 4,
        backgroundColor: darkBlueTheme.paperBackground,
        border: `1px solid ${darkBlueTheme.secondary}`,
        borderRadius: 3
      }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h5" sx={{ color: darkBlueTheme.textPrimary }}>
              Your KYC Status
            </Typography>
            <Button 
              variant="outlined" 
              onClick={refreshData}
              disabled={loading}
              startIcon={loading ? <CircularProgress size={20} /> : <RefreshIcon />}
              sx={{
                color: darkBlueTheme.accent,
                borderColor: darkBlueTheme.accent,
                '&:hover': {
                  backgroundColor: 'rgba(100, 255, 218, 0.1)',
                  borderColor: darkBlueTheme.accent
                }
              }}
            >
              Refresh
            </Button>
          </Box>
          
          {customerDetails ? (
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                {getStatusChip(customerDetails.status)}
                <Typography variant="body1" sx={{ color: darkBlueTheme.textPrimary }}>
                  <strong>Username:</strong> {customerDetails.username}
                </Typography>
              </Box>
              
              {customerDetails.bankId > 0 && (
                <Typography variant="body1" sx={{ mb: 1, color: darkBlueTheme.textPrimary }}>
                  <strong>Bank:</strong> {
                    availableBanks.find(b => b.id === customerDetails.bankId)?.name || 
                    `Bank ID: ${customerDetails.bankId}`
                  }
                </Typography>
              )}
              
              {customerDetails.approvalDate > 0 && (
                <Typography variant="body1" sx={{ mb: 1, color: darkBlueTheme.textPrimary }}>
                  <strong>Last Update:</strong> {new Date(customerDetails.approvalDate * 1000).toLocaleString()}
                </Typography>
              )}
              
              {customerDetails.remarks && (
                <Typography variant="body1" sx={{ mb: 1, color: darkBlueTheme.textPrimary }}>
                  <strong>Remarks:</strong> {customerDetails.remarks}
                </Typography>
              )}
              
              {customerDetails.verificationHash && (
                <Typography variant="body1" sx={{ color: darkBlueTheme.textPrimary }}>
                  <strong>Verification Hash:</strong> {customerDetails.verificationHash}
                </Typography>
              )}
            </Box>
          ) : (
            <Typography sx={{ color: darkBlueTheme.textSecondary }}>
              No KYC profile found. Please register first.
            </Typography>
          )}
        </CardContent>
      </Card>

      {/* KYC Process Stepper */}
      <Card sx={{ 
        mb: 4,
        backgroundColor: darkBlueTheme.paperBackground,
        border: `1px solid ${darkBlueTheme.secondary}`,
        borderRadius: 3
      }}>
        <CardContent>
          <Stepper activeStep={currentStep} alternativeLabel>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel sx={{ color: darkBlueTheme.textPrimary }}>
                  {label}
                </StepLabel>
              </Step>
            ))}
          </Stepper>

          {currentStep === 0 && (
            <Box sx={{ mt: 4, textAlign: 'center' }}>
              <Button 
                variant="outlined" 
                startIcon={<InfoIcon />} 
                onClick={() => setInfoOpen(true)} 
                sx={{ 
                  mb: 2,
                  color: darkBlueTheme.accent,
                  borderColor: darkBlueTheme.accent,
                  '&:hover': {
                    backgroundColor: 'rgba(100, 255, 218, 0.1)',
                    borderColor: darkBlueTheme.accent
                  }
                }}
              >
                View Required Documents
              </Button>
              
              <input 
                accept=".pdf,.jpg,.jpeg,.png" 
                style={{ display: 'none' }} 
                id="document-upload" 
                type="file" 
                multiple 
                onChange={handleDocumentUpload} 
              />
              <label htmlFor="document-upload">
                <Button 
                  variant="contained" 
                  component="span" 
                  startIcon={<CloudUploadIcon />} 
                  size="large" 
                  sx={{ 
                    mb: 2,
                    backgroundColor: darkBlueTheme.accent,
                    color: darkBlueTheme.primary,
                    '&:hover': {
                      backgroundColor: '#52d9c1'
                    }
                  }}
                >
                  Upload KYC Documents
                </Button>
              </label>
              
              {documents.length > 0 && (
                <Box sx={{ mt: 2 }}>
                  <Typography variant="subtitle1" sx={{ color: darkBlueTheme.textPrimary }}>
                    Selected Documents:
                  </Typography>
                  <List dense>
                    {documents.map((doc, index) => (
                      <ListItem key={index}>
                        <ListItemAvatar>
                          <Avatar sx={{ 
                            bgcolor: darkBlueTheme.secondary,
                            color: darkBlueTheme.accent
                          }}>
                            <DescriptionIcon />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText 
                          primary={
                            <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                              {doc.name}
                            </Typography>
                          } 
                          secondary={
                            <Typography sx={{ color: darkBlueTheme.textSecondary }}>
                              {`${(doc.size / 1024).toFixed(2)} KB - ${doc.type}`}
                            </Typography>
                          } 
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </Box>
          )}

          {currentStep === 1 && (
            <Box sx={{ mt: 4 }}>
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel sx={{ color: darkBlueTheme.textSecondary }}>
                  Select Bank for Verification
                </InputLabel>
                <Select
                  value={selectedBank}
                  label="Select Bank for Verification"
                  onChange={(e) => setSelectedBank(e.target.value)}
                  disabled={availableBanks.length === 0}
                  sx={{
                    color: darkBlueTheme.textPrimary,
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: darkBlueTheme.secondary
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: darkBlueTheme.accent
                    }
                  }}
                >
                  {availableBanks.length > 0 ? (
                    availableBanks.map((bank) => (
                      <MenuItem key={bank.id} value={bank.id}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <BusinessIcon sx={{ 
                            color: darkBlueTheme.textSecondary,
                            fontSize: 20
                          }} />
                          <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                            {bank.name} - {bank.country}
                          </Typography>
                        </Box>
                      </MenuItem>
                    ))
                  ) : (
                    <MenuItem disabled>
                      <Typography sx={{ color: darkBlueTheme.textSecondary }}>
                        No banks available
                      </Typography>
                    </MenuItem>
                  )}
                </Select>
              </FormControl>

              {Object.keys(ipfsHashes).length > 0 && (
                <Paper sx={{ 
                  mb: 3, 
                  p: 2, 
                  border: `1px solid ${darkBlueTheme.secondary}`,
                  backgroundColor: darkBlueTheme.secondary,
                  borderRadius: 2
                }}>
                  <Typography variant="subtitle2" sx={{ 
                    color: darkBlueTheme.textPrimary,
                    mb: 1
                  }}>
                    Document IPFS Hashes:
                  </Typography>
                  {Object.entries(ipfsHashes).map(([filename, hash]) => (
                    <Box key={filename} sx={{ mb: 2 }}>
                      <Typography variant="body2" sx={{ 
                        fontWeight: 'bold',
                        color: darkBlueTheme.textPrimary
                      }}>
                        {filename}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                        <TextField
                          value={hash}
                          size="small"
                          fullWidth
                          InputProps={{ 
                            readOnly: true,
                            style: {
                              color: darkBlueTheme.textPrimary,
                              backgroundColor: darkBlueTheme.paperBackground,
                              borderRadius: 1
                            }
                          }}
                          sx={{ mr: 1 }}
                        />
                        <Button 
                          size="small" 
                          onClick={() => copyToClipboard(hash)}
                          startIcon={<ContentCopyIcon />}
                          sx={{
                            color: darkBlueTheme.accent,
                            borderColor: darkBlueTheme.accent,
                            '&:hover': {
                              backgroundColor: 'rgba(100, 255, 218, 0.1)',
                              borderColor: darkBlueTheme.accent
                            }
                          }}
                        >
                          Copy
                        </Button>
                      </Box>
                      <Link 
                        href={`https://gateway.pinata.cloud/ipfs/${hash}`} 
                        target="_blank" 
                        rel="noopener"
                        sx={{ 
                          fontSize: '0.8rem',
                          color: darkBlueTheme.accent
                        }}
                      >
                        View on IPFS
                      </Link>
                    </Box>
                  ))}
                </Paper>
              )}

              <Button
                variant="contained"
                endIcon={<SendIcon />}
                onClick={handleSendForVerification}
                disabled={!selectedBank || loading || uploading}
                fullWidth
                size="large"
                sx={{
                  backgroundColor: darkBlueTheme.accent,
                  color: darkBlueTheme.primary,
                  '&:hover': {
                    backgroundColor: '#52d9c1',
                    transform: 'translateY(-2px)',
                    boxShadow: `0 4px 15px ${darkBlueTheme.accent}40`
                  },
                  transition: 'all 0.3s ease',
                  py: 1.5
                }}
              >
                {uploading ? 'Uploading to IPFS...' : loading ? <CircularProgress size={24} /> : 'Send for Verification'}
              </Button>
            </Box>
          )}

          {currentStep === 2 && (
            <Box sx={{ mt: 4, textAlign: 'center' }}>
              {verificationStatus === 1 ? (
                <>
                  <VerifiedIcon sx={{ 
                    fontSize: 60, 
                    mb: 2,
                    color: darkBlueTheme.accent
                  }} />
                  <Typography variant="h5" sx={{ 
                    color: darkBlueTheme.textPrimary,
                    mb: 2
                  }}>
                    Your KYC Documents Are Verified!
                  </Typography>
                  {verificationHash && (
                    <Typography variant="body1" sx={{ 
                      mb: 2,
                      color: darkBlueTheme.textSecondary
                    }}>
                      Transaction Hash: {verificationHash}
                    </Typography>
                  )}
                  
                  <Box sx={{ mt: 3, textAlign: 'left' }}>
                    <Typography variant="h6" sx={{ 
                      color: darkBlueTheme.textPrimary,
                      mb: 2
                    }}>
                      Your Documents:
                    </Typography>
                    {customerDocuments.map((doc, index) => (
                      <Card key={index} sx={{ 
                        mb: 2, 
                        p: 2,
                        backgroundColor: darkBlueTheme.secondary,
                        border: `1px solid ${darkBlueTheme.secondary}`
                      }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body1" sx={{ color: darkBlueTheme.textPrimary }}>
                            Document {index + 1}
                          </Typography>
                          <Box>
                            <Button 
                              size="small" 
                              onClick={() => copyToClipboard(doc.docHash)}
                              startIcon={<ContentCopyIcon />}
                              sx={{ 
                                mr: 1,
                                color: darkBlueTheme.accent,
                                borderColor: darkBlueTheme.accent,
                                '&:hover': {
                                  backgroundColor: 'rgba(100, 255, 218, 0.1)',
                                  borderColor: darkBlueTheme.accent
                                }
                              }}
                            >
                              Copy Hash
                            </Button>
                            <Button 
                              variant="outlined" 
                              size="small"
                              href={`https://gateway.pinata.cloud/ipfs/${doc.docHash}`}
                              target="_blank"
                              sx={{
                                color: darkBlueTheme.accent,
                                borderColor: darkBlueTheme.accent,
                                '&:hover': {
                                  backgroundColor: 'rgba(100, 255, 218, 0.1)',
                                  borderColor: darkBlueTheme.accent
                                }
                              }}
                            >
                              View Document
                            </Button>
                          </Box>
                        </Box>
                        <Typography variant="body2" sx={{ 
                          mt: 1,
                          color: darkBlueTheme.textSecondary
                        }}>
                          Type: {doc.docType}
                        </Typography>
                        <Typography variant="body2" sx={{ 
                          fontFamily: 'monospace', 
                          wordBreak: 'break-all',
                          color: darkBlueTheme.textPrimary
                        }}>
                          IPFS Hash: {doc.docHash}
                        </Typography>
                      </Card>
                    ))}
                  </Box>
                </>
              ) : verificationStatus === 2 ? (
                <>
                  <VerifiedIcon sx={{ 
                    fontSize: 60, 
                    mb: 2,
                    color: '#ff6e6e'
                  }} />
                  <Typography variant="h5" sx={{ 
                    color: darkBlueTheme.textPrimary,
                    mb: 2
                  }}>
                    Your KYC Was Rejected
                  </Typography>
                  {customerDetails?.remarks && (
                    <Typography variant="body1" sx={{ 
                      mb: 2,
                      color: darkBlueTheme.textSecondary
                    }}>
                      Reason: {customerDetails.remarks}
                    </Typography>
                  )}
                  <Button 
                    variant="contained" 
                    onClick={() => setCurrentStep(0)}
                    sx={{ 
                      mt: 2,
                      backgroundColor: darkBlueTheme.accent,
                      color: darkBlueTheme.primary,
                      '&:hover': {
                        backgroundColor: '#52d9c1'
                      }
                    }}
                  >
                    Resubmit Documents
                  </Button>
                </>
              ) : (
                <>
                  <Typography variant="h5" sx={{ 
                    color: darkBlueTheme.textPrimary,
                    mb: 2
                  }}>
                    Verification In Progress
                  </Typography>
                  <Typography variant="body1" sx={{ color: darkBlueTheme.textSecondary }}>
                    Your documents are being reviewed by {availableBanks.find(b => b.id === selectedBank)?.name || 'the bank'}
                  </Typography>
                  
                  {Object.keys(ipfsHashes).length > 0 && (
                    <Box sx={{ mt: 3, textAlign: 'left' }}>
                      <Typography variant="subtitle1" sx={{ color: darkBlueTheme.textPrimary }}>
                        Uploaded Documents:
                      </Typography>
                      {Object.entries(ipfsHashes).map(([filename, hash]) => (
                        <Box key={filename} sx={{ 
                          mb: 1, 
                          p: 1, 
                          borderBottom: `1px solid ${darkBlueTheme.secondary}`
                        }}>
                          <Typography variant="body2" sx={{ color: darkBlueTheme.textPrimary }}>
                            {filename}
                          </Typography>
                          <Typography variant="caption" sx={{ 
                            fontFamily: 'monospace', 
                            wordBreak: 'break-all',
                            color: darkBlueTheme.textSecondary
                          }}>
                            {hash}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  )}
                </>
              )}
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Bank Requests Section */}
      <Divider sx={{ 
        my: 4,
        backgroundColor: darkBlueTheme.secondary
      }} />
      <Typography variant="h5" sx={{ 
        color: darkBlueTheme.textPrimary,
        mb: 3
      }}>
        Bank Requests for Your KYC
      </Typography>
      
      {loading ? (
        <CircularProgress sx={{ color: darkBlueTheme.accent }} />
      ) : bankRequests.length > 0 ? (
        <Card sx={{ 
          backgroundColor: darkBlueTheme.paperBackground,
          border: `1px solid ${darkBlueTheme.secondary}`,
          borderRadius: 3
        }}>
          <List>
            {bankRequests.map((request, index) => {
              const bank = availableBanks.find(b => b.id === request.bankId);
              return (
                <React.Fragment key={request.id || index}>
                  <ListItem>
                    <ListItemAvatar>
                      <Avatar sx={{ 
                        bgcolor: darkBlueTheme.secondary,
                        color: darkBlueTheme.accent
                      }}>
                        {bank?.name?.charAt(0) || 'B'}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={
                        <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                          {bank?.name || 'Unknown Bank'}
                        </Typography>
                      }
                      secondary={
                        <>
                          <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                            Requested on {new Date(request.requestDate).toLocaleString()}
                          </Typography>
                          <Typography variant="body2" sx={{ color: darkBlueTheme.textSecondary }}>
                            Status: {request.responded ? 
                              (request.accessGranted ? 'Access Granted' : 'Access Denied') : 
                              'Pending Response'}
                          </Typography>
                        </>
                      }
                    />
                    <Chip 
                      label={request.responded ? 
                        (request.accessGranted ? 'Approved' : 'Rejected') : 
                        'Pending'} 
                      sx={{ 
                        backgroundColor: request.responded ? 
                          (request.accessGranted ? 'rgba(100, 255, 218, 0.2)' : 'rgba(255, 0, 0, 0.2)') : 
                          'rgba(255, 193, 7, 0.2)',
                        color: request.responded ? 
                          (request.accessGranted ? darkBlueTheme.accent : '#ff6e6e') : 
                          'warning.light'
                      }}
                    />
                  </ListItem>
                  {index < bankRequests.length - 1 && (
                    <Divider sx={{ backgroundColor: darkBlueTheme.secondary }} />
                  )}
                </React.Fragment>
              );
            })}
          </List>
        </Card>
      ) : (
        <Typography sx={{ color: darkBlueTheme.textSecondary }}>
          No bank requests yet
        </Typography>
      )}

      {/* Document Requirements Dialog */}
      <Dialog 
        open={infoOpen} 
        onClose={() => setInfoOpen(false)} 
        maxWidth="md"
        PaperProps={{
          sx: {
            backgroundColor: darkBlueTheme.paperBackground,
            color: darkBlueTheme.textPrimary,
            border: `1px solid ${darkBlueTheme.secondary}`
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: darkBlueTheme.secondary,
          borderBottom: `1px solid ${darkBlueTheme.secondary}`
        }}>
          KYC Document Requirements
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: darkBlueTheme.textSecondary }}>
            Please upload clear copies of these documents:
          </DialogContentText>
          <List>
            {requiredDocuments.map((doc, index) => (
              <ListItem key={index}>
                <ListItemText 
                  primary={
                    <Typography sx={{ color: darkBlueTheme.textPrimary }}>
                      {`${index + 1}. ${doc.name}`}
                    </Typography>
                  } 
                  secondary={
                    <Typography sx={{ color: darkBlueTheme.textSecondary }}>
                      {`Accepted formats: ${doc.types.join(', ')}`}
                    </Typography>
                  } 
                  sx={{ py: 1 }} 
                />
              </ListItem>
            ))}
          </List>
          <Paper sx={{ 
            p: 2, 
            mt: 2,
            backgroundColor: darkBlueTheme.secondary,
            borderRadius: 2
          }}>
            <Typography variant="subtitle2" sx={{ 
              color: darkBlueTheme.textPrimary,
              mb: 1
            }}>
              <strong>Requirements:</strong>
            </Typography>
            <Box component="ul" sx={{ 
              pl: 2,
              color: darkBlueTheme.textSecondary
            }}>
              <li><Typography variant="body2">Files must be under 10MB each</Typography></li>
              <li><Typography variant="body2">Accepted formats: PDF, JPG, PNG</Typography></li>
              <li><Typography variant="body2">Documents must be valid and not expired</Typography></li>
              <li><Typography variant="body2">All text must be clearly visible</Typography></li>
            </Box>
          </Paper>
        </DialogContent>
        <DialogActions sx={{ 
          p: 2,
          borderTop: `1px solid ${darkBlueTheme.secondary}`
        }}>
          <Button 
            onClick={() => setInfoOpen(false)}
            sx={{ 
              color: darkBlueTheme.textSecondary,
              '&:hover': {
                color: darkBlueTheme.accent
              }
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CustomerDashboard;